"""Graph algorithms: BFS, DFS, reachability, connected components.

All functions accept anything with .locations() and .neighbors(name)
(CampusGraph or AdjacencyMatrix).  V = vertices, E = edges.
"""
from collections import deque
from typing import Dict, List, Optional, Set


# --------------------------------------------------------------------- BFS
def bfs_shortest_path(graph, source: str, destination: str) -> Optional[List[str]]:
    """Return a path with the MINIMUM number of edges, or None if unreachable.

    BFS explores level by level using a FIFO queue, so the first time we
    reach a vertex is via a shortest path (true for unweighted graphs).
    The path is rebuilt by walking the `parent` links backwards.

    Time : O(V + E) with adjacency list (O(V^2) with matrix)
    Space: O(V) for queue + parent/visited map
    """
    if source == destination:
        return [source]
    parent: Dict[str, Optional[str]] = {source: None}   # doubles as visited set
    queue = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in graph.neighbors(current):
            if nxt not in parent:
                parent[nxt] = current
                if nxt == destination:                  # early exit
                    return _rebuild(parent, destination)
                queue.append(nxt)
    return None


def _rebuild(parent: Dict[str, Optional[str]], end: str) -> List[str]:
    """Path reconstruction using predecessor tracking."""
    path = []
    node: Optional[str] = end
    while node is not None:
        path.append(node)
        node = parent[node]
    return path[::-1]


def bfs_order(graph, start: str) -> List[str]:
    """Locations in BFS visiting order. O(V + E)."""
    seen, order, queue = {start}, [], deque([start])
    while queue:
        cur = queue.popleft()
        order.append(cur)
        for nxt in graph.neighbors(cur):
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return order


def bfs_distances(graph, start: str) -> Dict[str, int]:
    """Edge-count distance from `start` to every reachable location."""
    dist = {start: 0}
    queue = deque([start])
    while queue:
        cur = queue.popleft()
        for nxt in graph.neighbors(cur):
            if nxt not in dist:
                dist[nxt] = dist[cur] + 1
                queue.append(nxt)
    return dist


# --------------------------------------------------------------------- DFS
def dfs_iterative(graph, start: str) -> List[str]:
    """DFS using an explicit stack. Returns visiting order.

    Neighbours are pushed in reverse so they are visited in listed order,
    giving the same order as the recursive version.
    Time O(V + E), Space O(V).
    """
    visited: Set[str] = set()
    order: List[str] = []
    stack = [start]
    while stack:
        cur = stack.pop()
        if cur in visited:
            continue
        visited.add(cur)
        order.append(cur)
        for nxt in reversed(graph.neighbors(cur)):
            if nxt not in visited:
                stack.append(nxt)
    return order


def dfs_recursive(graph, start: str, visited: Optional[Set[str]] = None,
                  order: Optional[List[str]] = None) -> List[str]:
    """DFS using recursion (call stack = stack). Depth up to O(V)."""
    if visited is None:
        visited, order = set(), []
    visited.add(start)
    order.append(start)
    for nxt in graph.neighbors(start):
        if nxt not in visited:
            dfs_recursive(graph, nxt, visited, order)
    return order


def is_reachable(graph, source: str, destination: str) -> bool:
    """True if a path exists (DFS)."""
    return destination in dfs_iterative(graph, source)


def dfs_any_path(graph, source: str, destination: str) -> Optional[List[str]]:
    """Some path found by DFS - NOT guaranteed shortest (used for comparison)."""
    parent: Dict[str, Optional[str]] = {}
    stack = [(source, None)]
    while stack:
        cur, par = stack.pop()
        if cur in parent:
            continue
        parent[cur] = par
        if cur == destination:
            return _rebuild(parent, cur)
        for nxt in reversed(graph.neighbors(cur)):
            if nxt not in parent:
                stack.append((nxt, cur))
    return None


# ------------------------------------------------- reachability / components
def unreachable_from(graph, start: str) -> List[str]:
    """Locations that cannot be reached from `start`."""
    reach = set(dfs_iterative(graph, start))
    return [n for n in graph.locations() if n not in reach]


def connected_components(graph) -> List[List[str]]:
    """All connected components. Total O(V + E)."""
    seen: Set[str] = set()
    comps = []
    for n in graph.locations():
        if n not in seen:
            comp = dfs_iterative(graph, n)
            seen.update(comp)
            comps.append(comp)
    return comps
