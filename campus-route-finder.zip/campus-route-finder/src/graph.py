"""Graph representations for the Campus Route Finder.

Two interchangeable representations are provided:
  * CampusGraph     - adjacency list (dict of lists)   -> O(V + E) space
  * AdjacencyMatrix - V x V 0/1 matrix                 -> O(V^2) space

Both expose the same small interface (locations(), neighbors(), has_edge()),
so every algorithm in algorithms.py works with either one.
"""
from typing import Dict, List, Optional


class CampusGraph:
    """Undirected, unweighted graph stored as an adjacency list."""

    def __init__(self) -> None:
        self.adj: Dict[str, List[str]] = {}

    # ---- construction -------------------------------------------------
    def add_location(self, name: str) -> None:
        """Add a vertex. O(1)."""
        self.adj.setdefault(name, [])

    def add_path(self, a: str, b: str) -> None:
        """Add an undirected edge a <-> b. O(1) (plus duplicate check O(deg))."""
        if a == b:
            raise ValueError("A location cannot have a path to itself.")
        self.add_location(a)
        self.add_location(b)
        if b not in self.adj[a]:
            self.adj[a].append(b)
            self.adj[b].append(a)

    @classmethod
    def from_file(cls, filepath: str) -> "CampusGraph":
        """Build a graph from the text format used in data/campus_graph.txt."""
        g = cls()
        with open(filepath, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("LOCATION "):
                    g.add_location(line[len("LOCATION "):].strip())
                elif line.startswith("PATH "):
                    a, b = (p.strip() for p in line[len("PATH "):].split("|"))
                    g.add_path(a, b)
                else:
                    raise ValueError(f"Bad line in graph file: {line!r}")
        return g

    # ---- queries ------------------------------------------------------
    def locations(self) -> List[str]:
        return list(self.adj)

    def neighbors(self, name: str) -> List[str]:
        return self.adj[name]

    def has_edge(self, a: str, b: str) -> bool:
        return b in self.adj[a]          # O(deg(a))

    def num_vertices(self) -> int:
        return len(self.adj)

    def num_edges(self) -> int:
        return sum(len(v) for v in self.adj.values()) // 2

    def resolve(self, text: str) -> Optional[str]:
        """Case-insensitive lookup of a user-typed location name."""
        for name in self.adj:
            if name.lower() == text.strip().lower():
                return name
        return None

    def to_matrix(self) -> "AdjacencyMatrix":
        return AdjacencyMatrix(self)

    def __str__(self) -> str:
        width = max(len(n) for n in self.adj)
        return "\n".join(f"{n:<{width}} -> {', '.join(nb) if nb else '(none)'}"
                         for n, nb in self.adj.items())


class AdjacencyMatrix:
    """Same graph stored as a V x V matrix (matrix[i][j] == 1 if edge)."""

    def __init__(self, graph: CampusGraph) -> None:
        self.names = graph.locations()
        self.index = {n: i for i, n in enumerate(self.names)}
        v = len(self.names)
        self.matrix = [[0] * v for _ in range(v)]          # O(V^2) space
        for a in self.names:
            for b in graph.neighbors(a):
                self.matrix[self.index[a]][self.index[b]] = 1

    def locations(self) -> List[str]:
        return self.names

    def has_edge(self, a: str, b: str) -> bool:
        return self.matrix[self.index[a]][self.index[b]] == 1   # O(1)

    def neighbors(self, name: str) -> List[str]:
        """Must scan a whole row: O(V) regardless of degree."""
        row = self.matrix[self.index[name]]
        return [self.names[j] for j, x in enumerate(row) if x]

    def __str__(self) -> str:
        legend = "\n".join(f"  {i:>2} = {n}" for i, n in enumerate(self.names))
        header = "    " + " ".join(f"{i:>2}" for i in range(len(self.names)))
        rows = [f"{i:>2}  " + " ".join(f"{x:>2}" for x in r)
                for i, r in enumerate(self.matrix)]
        return legend + "\n\n" + header + "\n" + "\n".join(rows)
