"""Runs the program's commands and renders each real output as a terminal-style PNG."""
import subprocess, sys
from PIL import Image, ImageDraw, ImageFont

FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 15)
SHOTS = [
    ("01_graph_input_adjacency_list", "$ python main.py graph", ["graph"]),
    ("02_adjacency_matrix", "$ python main.py matrix", ["matrix"]),
    ("03_bfs_route", '$ python main.py bfs "Main Gate" Auditorium', ["bfs", "Main Gate", "Auditorium"]),
    ("04_dfs_traversal", "$ python main.py dfs Library", ["dfs", "Library"]),
    ("05_reachability_disconnected", '$ python main.py reach "Main Gate"', ["reach", "Main Gate"]),
    ("06_unreachable_bfs", '$ python main.py bfs "Main Gate" Hostel', ["bfs", "Main Gate", "Hostel"]),
    ("07_comparison", "$ python main.py compare", ["compare"]),
    ("08_test_cases", "$ python main.py all-tests", ["all-tests"]),
]
for name, title, args in SHOTS:
    out = subprocess.run([sys.executable, "main.py", *args], capture_output=True, text=True).stdout
    lines = [title, ""] + out.rstrip().split("\n")
    w = int(max(FONT.getlength(l) for l in lines)) + 40
    h = len(lines) * 21 + 50
    img = Image.new("RGB", (w, h + 28), "#1e1e1e")
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, 28], fill="#333")
    for i, c in enumerate(("#ff5f56", "#ffbd2e", "#27c93f")):
        d.ellipse([12 + i * 20, 8, 24 + i * 20, 20], fill=c)
    for i, l in enumerate(lines):
        col = "#7fdc7f" if i == 0 else ("#ff7b72" if "FAIL" in l else "#d4d4d4")
        if "PASS" in l and i > 1: col = "#9be29b"
        d.text((20, 40 + i * 21), l, font=FONT, fill=col)
    img.save(f"screenshots/{name}.png")
    open(f"screenshots/{name}.txt", "w").write(out)
    print("saved", name)
