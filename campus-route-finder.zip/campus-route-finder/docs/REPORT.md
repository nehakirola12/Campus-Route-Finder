# Campus Route Finder – Short Report

## 1. Problem and approach
The campus is modelled as an undirected, unweighted graph: each **location** is a vertex and
each **walkable path** is an edge. The program loads 11 locations and 13 paths from
`data/campus_graph.txt`, finds routes between two places, lists everything reachable from a
chosen start, and reports locations that are disconnected from it.

## 2. Graph representation
**Adjacency list** (`CampusGraph`): a dictionary mapping each location to a list of neighbours.
**Adjacency matrix** (`AdjacencyMatrix`): a V × V table where `matrix[i][j] = 1` if a path exists.
Both expose the same interface, so every algorithm runs unchanged on either.

| Operation | Adjacency list | Adjacency matrix |
|---|---|---|
| Space | O(V + E) | O(V²) |
| Is there an edge (a, b)? | O(deg(a)) | **O(1)** |
| List neighbours of a vertex | **O(deg(v))** | O(V) |
| Add an edge | O(1) | O(1) |
| Add a vertex | O(1) | O(V²) (rebuild) |
| BFS / DFS whole graph | **O(V + E)** | O(V²) |
| Best for | Sparse graphs (campus maps) | Dense graphs, frequent edge look-ups |

A campus map is **sparse** (here E = 13 while V² = 121), so the adjacency list is the better choice.
Measured on a 1,500-node sparse graph, BFS took about 0.7 ms with the list and about 100 ms
with the matrix (exact timings vary by machine).

## 3. Algorithms

### BFS – shortest route (minimum edges)
A FIFO queue explores locations level by level. Because every edge has the same cost, the first
time BFS reaches a location it has used the fewest possible edges. A `parent` dictionary doubles
as the visited set; once the destination is found, the route is rebuilt by following parents back
to the source and reversing the result (**path reconstruction**).

### DFS – reachability and traversal
DFS goes as deep as possible before backtracking. It is implemented twice: with an **explicit stack**
and with **recursion** (the call stack). It is used to list all reachable locations, test whether a
destination is reachable, and find **connected components** (run DFS from every unvisited vertex).
DFS can return a route, but it is **not guaranteed to be shortest**.

Example, Main Gate → Auditorium:
```
ADJACENCY LIST vs ADJACENCY MATRIX
------------------------------------------------------------
  BFS route length, list vs matrix: 3 vs 3 edges (same length: True; order of equal-length routes may differ)
  Matrix cells stored    : 121
  List entries stored    : 26 (= 2E, plus V keys)
  Fully connected pair?  : has_edge list/matrix = True / True

  BFS vs DFS route Main Gate -> Auditorium
    BFS: Main Gate -> Parking -> Cafeteria -> Auditorium  (3 edges)
    DFS: Main Gate -> Parking -> Cafeteria -> Library -> Block 1 -> Block 2 -> Auditorium  (6 edges)  <- not guaranteed shortest
  BFS on 1500-node graph, list  : 1.07 ms
  BFS on 1500-node graph, matrix: 108.91 ms
```
(the last timing lines vary per machine). DFS wandered through 6 edges where BFS needed 3.

## 4. Complexity analysis
Let V = number of locations and E = number of paths.

**BFS (adjacency list):** each vertex is enqueued at most once (O(V)) and each adjacency list is
scanned once (the sum of all degrees is 2E), so **time = O(V + E)**. The queue and parent/visited
map hold at most V entries, so **space = O(V)**.

**DFS (adjacency list):** each vertex is visited once and each edge examined twice (once from each end),
so **time = O(V + E)**. The visited set and the stack (or recursion depth in the worst case, a long
chain) need **space = O(V)**.

**With an adjacency matrix**, finding neighbours of a vertex needs a full row scan of O(V), so BFS/DFS
become **O(V²)** in time. Storage is O(V²) regardless of how few edges exist.

**Connected components:** one DFS pass over the whole graph, **O(V + E)**.

## 5. Sample input / output
**Input** (`data/campus_graph.txt`, excerpt):
```
LOCATION Main Gate
PATH Main Gate | Parking
PATH Parking | Cafeteria
PATH Cafeteria | Auditorium
```
**Output:**
```
BFS ROUTE: Main Gate -> Auditorium
------------------------------------------------------------
  Route : Main Gate -> Parking -> Cafeteria -> Auditorium
  Stops : 4 locations, 3 path(s) (minimum possible)
```
```
BFS ROUTE: Main Gate -> Hostel
------------------------------------------------------------
  No route exists from Main Gate to Hostel (they are in different parts of campus).
```

## 6. Test cases (expected vs actual)
```
ID  Case                     Expected                                             Actual                                               Result
--------------------------------------------------------------------------------------------------------------------------------------------
T1  Direct route             Main Gate > Library                                  Main Gate > Library                                  PASS
T2  Multi-stop route         Main Gate > Parking > Cafeteria > Auditorium         Main Gate > Parking > Cafeteria > Auditorium         PASS
T3  Unreachable              No route                                             No route                                             PASS
T4  Source == dest           Lab                                                  Lab                                                  PASS
T5  Multi-stop (3 edges)     Admin Office > Library > Block 1 > Lab               Admin Office > Library > Block 1 > Lab               PASS
T6  DFS reachable set        9 locations, no Hostel                               9 locations, Hostel in set: False                    PASS
T7  Connected components     2                                                    2                                                    PASS
--------------------------------------------------------------------------------------------------------------------------------------------
ALL TESTS PASSED
```
Unit tests (`python -m unittest tests.test_cases`) additionally check that BFS gives equal-length
routes on both representations for **every** pair of locations, and that iterative and recursive DFS
produce the same order from every start location.

## 7. Screenshots
See the `screenshots/` folder: graph input (01), adjacency matrix (02), BFS route (03), DFS traversal (04),
reachability / disconnected locations (05), unreachable destination (06), comparison (07), test cases (08).

## 8. Conclusion
BFS is the right tool for "fewest paths" routing on an unweighted graph; DFS is ideal for reachability
and components. For a sparse campus map, an adjacency list gives O(V + E) traversals and less memory
than a matrix. If walking distances were added (weighted edges), Dijkstra's algorithm would replace BFS.
