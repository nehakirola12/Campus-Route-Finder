"""Test cases: expected vs actual output.

Run:  python -m tests.test_cases        (table of expected vs actual)
      python -m unittest tests.test_cases (standard unittest run)
"""
import os
import unittest

from src.graph import CampusGraph
from src.algorithms import (bfs_shortest_path, dfs_iterative, dfs_recursive,
                            is_reachable, unreachable_from, connected_components)

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "data", "campus_graph.txt")

# (id, description, source, destination, expected path or None)
BFS_CASES = [
    ("T1", "Direct route",        "Main Gate", "Library",
     ["Main Gate", "Library"]),
    ("T2", "Multi-stop route",    "Main Gate", "Auditorium",
     ["Main Gate", "Parking", "Cafeteria", "Auditorium"]),
    ("T3", "Unreachable",         "Main Gate", "Hostel", None),
    ("T4", "Source == dest",      "Lab", "Lab", ["Lab"]),
    ("T5", "Multi-stop (3 edges)", "Admin Office", "Lab",
     ["Admin Office", "Library", "Block 1", "Lab"]),
]


def run_table(g=None):
    g = g or CampusGraph.from_file(DATA)
    print(f"{'ID':<3} {'Case':<24} {'Expected':<52} {'Actual':<52} Result")
    print("-" * 140)
    ok_all = True
    for tid, desc, s, d, exp in BFS_CASES:
        act = bfs_shortest_path(g, s, d)
        ok = act == exp
        ok_all &= ok
        fmt = lambda p: " > ".join(p) if p else "No route"
        print(f"{tid:<3} {desc:<24} {fmt(exp):<52} {fmt(act):<52} {'PASS' if ok else 'FAIL'}")
    reach = sorted(dfs_iterative(g, "Main Gate"))
    exp_n = 9
    ok = len(reach) == exp_n and "Hostel" not in reach
    ok_all &= ok
    print(f"{'T6':<3} {'DFS reachable set':<24} {str(exp_n) + ' locations, no Hostel':<52} "
          f"{str(len(reach)) + ' locations, Hostel in set: ' + str('Hostel' in reach):<52} "
          f"{'PASS' if ok else 'FAIL'}")
    comps = connected_components(g)
    ok = len(comps) == 2
    ok_all &= ok
    print(f"{'T7':<3} {'Connected components':<24} {'2':<52} {str(len(comps)):<52} "
          f"{'PASS' if ok else 'FAIL'}")
    print("-" * 140)
    print("ALL TESTS PASSED" if ok_all else "SOME TESTS FAILED")


class TestCampus(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g = CampusGraph.from_file(DATA)

    def test_bfs_cases(self):
        for tid, desc, s, d, exp in BFS_CASES:
            with self.subTest(tid):
                self.assertEqual(bfs_shortest_path(self.g, s, d), exp)

    def test_graph_size(self):
        self.assertGreaterEqual(self.g.num_vertices(), 8)

    def test_bfs_is_shortest_on_both_representations(self):
        m = self.g.to_matrix()
        for a in self.g.locations():
            for b in self.g.locations():
                pl, pm = bfs_shortest_path(self.g, a, b), bfs_shortest_path(m, a, b)
                self.assertEqual(None if pl is None else len(pl),
                                 None if pm is None else len(pm))

    def test_dfs_variants_agree(self):
        for n in self.g.locations():
            self.assertEqual(dfs_iterative(self.g, n), dfs_recursive(self.g, n))

    def test_reachability(self):
        self.assertTrue(is_reachable(self.g, "Lab", "Parking"))
        self.assertFalse(is_reachable(self.g, "Lab", "Sports Ground"))
        self.assertEqual(sorted(unreachable_from(self.g, "Lab")),
                         ["Hostel", "Sports Ground"])


if __name__ == "__main__":
    run_table()
