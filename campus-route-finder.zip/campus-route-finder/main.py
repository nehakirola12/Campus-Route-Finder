"""Campus Route Finder - command line interface.

Interactive menu:      python main.py
Single commands:       python main.py graph | matrix | bfs "Main Gate" Auditorium
                       python main.py dfs Library | reach "Main Gate" | compare
                       python main.py all-tests
"""
import os
import sys
import time

from src.graph import CampusGraph
from src.algorithms import (bfs_shortest_path, bfs_order, bfs_distances,
                            dfs_iterative, dfs_recursive, dfs_any_path,
                            is_reachable, unreachable_from, connected_components)

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "data", "campus_graph.txt")


def need(graph, text):
    """Resolve a user-typed name; exit nicely if unknown."""
    name = graph.resolve(text)
    if name is None:
        print(f"  ! Unknown location: '{text}'. Valid: {', '.join(graph.locations())}")
    return name


def show_graph(g):
    print(f"CAMPUS GRAPH (adjacency list)  V={g.num_vertices()}  E={g.num_edges()}")
    print("-" * 60)
    print(g)


def show_matrix(g):
    print("CAMPUS GRAPH (adjacency matrix)")
    print("-" * 60)
    print(g.to_matrix())


def show_bfs(g, s, d):
    s, d = need(g, s), need(g, d)
    if not s or not d:
        return
    print(f"BFS ROUTE: {s} -> {d}")
    print("-" * 60)
    path = bfs_shortest_path(g, s, d)
    if path is None:
        print(f"  No route exists from {s} to {d} (they are in different parts of campus).")
    else:
        print("  Route :", " -> ".join(path))
        print(f"  Stops : {len(path)} locations, {len(path) - 1} path(s) (minimum possible)")


def show_dfs(g, start):
    start = need(g, start)
    if not start:
        return
    print(f"DFS TRAVERSAL from {start}")
    print("-" * 60)
    it, rec = dfs_iterative(g, start), dfs_recursive(g, start)
    print("  Visit order (stack)    :", " -> ".join(it))
    print("  Visit order (recursion):", " -> ".join(rec))
    print("  Both agree             :", it == rec)


def show_reach(g, start):
    start = need(g, start)
    if not start:
        return
    reach = dfs_iterative(g, start)
    dist = bfs_distances(g, start)
    print(f"REACHABILITY from {start}")
    print("-" * 60)
    print(f"  Reachable ({len(reach)}/{g.num_vertices()}):")
    for n in sorted(reach, key=lambda x: dist[x]):
        print(f"     {n:<14} {dist[n]} step(s) away")
    lost = unreachable_from(g, start)
    print(f"  Disconnected from {start}: {', '.join(lost) if lost else 'none'}")
    comps = connected_components(g)
    print(f"  Connected components in campus: {len(comps)}")
    for i, c in enumerate(comps, 1):
        print(f"     #{i}: {', '.join(c)}")


def show_compare(g):
    m = g.to_matrix()
    print("ADJACENCY LIST vs ADJACENCY MATRIX")
    print("-" * 60)
    s, d = "Main Gate", "Auditorium"
    pl, pm = bfs_shortest_path(g, s, d), bfs_shortest_path(m, s, d)
    print(f"  BFS route length, list vs matrix: {len(pl) - 1} vs {len(pm) - 1} edges "
          f"(same length: {len(pl) == len(pm)}; order of equal-length routes may differ)")
    print("  Matrix cells stored    :", len(m.matrix) ** 2)
    print("  List entries stored    :", sum(len(v) for v in g.adj.values()),
          "(= 2E, plus V keys)")
    print("  Fully connected pair?  : has_edge list/matrix =",
          g.has_edge("Main Gate", "Library"), "/", m.has_edge("Main Gate", "Library"))
    # BFS vs DFS path quality
    bp, dp = bfs_shortest_path(g, s, d), dfs_any_path(g, s, d)
    print(f"\n  BFS vs DFS route {s} -> {d}")
    print(f"    BFS: {' -> '.join(bp)}  ({len(bp) - 1} edges)")
    print(f"    DFS: {' -> '.join(dp)}  ({len(dp) - 1} edges)  <- not guaranteed shortest")
    # tiny timing demo on a large synthetic ring+chords graph
    big = CampusGraph()
    n = 1500
    for i in range(n):
        big.add_path(f"N{i}", f"N{(i + 1) % n}")
        j = (i * 7 + 3) % n
        if j != i:
            big.add_path(f"N{i}", f"N{j}")
    bm = big.to_matrix()
    for label, gr in (("list  ", big), ("matrix", bm)):
        t = time.perf_counter()
        bfs_shortest_path(gr, "N0", "N750")
        print(f"  BFS on {n}-node graph, {label}: {(time.perf_counter() - t) * 1000:.2f} ms")


def menu(g):
    while True:
        print("\n===== CAMPUS ROUTE FINDER =====")
        print(" 1. Show graph (adjacency list)\n 2. Show adjacency matrix")
        print(" 3. Find route (BFS)\n 4. DFS traversal\n 5. Reachable / disconnected locations")
        print(" 6. Compare list vs matrix, BFS vs DFS\n 7. Run test cases\n 0. Exit")
        c = input("Choice: ").strip()
        if c == "0":
            break
        elif c == "1": show_graph(g)
        elif c == "2": show_matrix(g)
        elif c == "3":
            print("Locations:", ", ".join(g.locations()))
            show_bfs(g, input("Source: "), input("Destination: "))
        elif c == "4": show_dfs(g, input("Start: "))
        elif c == "5": show_reach(g, input("Start: "))
        elif c == "6": show_compare(g)
        elif c == "7":
            from tests.test_cases import run_table
            run_table(g)
        else:
            print("Invalid choice.")


def main(argv):
    g = CampusGraph.from_file(DATA_FILE)
    if len(argv) <= 1:
        return menu(g)
    cmd, args = argv[1], argv[2:]
    try:
        {"graph": lambda: show_graph(g), "matrix": lambda: show_matrix(g),
         "bfs": lambda: show_bfs(g, args[0], args[1]), "dfs": lambda: show_dfs(g, args[0]),
         "reach": lambda: show_reach(g, args[0]), "compare": lambda: show_compare(g),
         "all-tests": lambda: __import__("tests.test_cases", fromlist=["x"]).run_table(g),
         }[cmd]()
    except (KeyError, IndexError):
        print(__doc__)


if __name__ == "__main__":
    main(sys.argv)
